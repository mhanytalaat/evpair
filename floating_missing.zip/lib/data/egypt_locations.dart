/// Curated list of Egyptian governorates/cities and their areas/
/// compounds, used everywhere a driver picks a location: the Home
/// screen station filter, and the Home Installation & Equipment
/// service-request form. Keeping this as a single shared data source
/// means every part of the app uses identical spelling, so filtering
/// and reporting stay consistent.
///
/// Priority locations (Cairo, Giza, North Coast) are listed first since
/// they're EVPair's primary coverage area; the rest are ordered
/// alphabetically by governorate, exactly as provided.
class EgyptGovernorate {
  final String name;
  final List<String> areas;
  final bool isPriority;

  const EgyptGovernorate({
    required this.name,
    required this.areas,
    this.isPriority = false,
  });
}

const List<EgyptGovernorate> kEgyptGovernorates = [
  // ---------------------------------------------------------------
  // PRIORITY LOCATIONS
  // ---------------------------------------------------------------
  EgyptGovernorate(
    name: 'Cairo',
    isPriority: true,
    areas: [
      'Badr City',
      'Cairo Festival City',
      'Choueifat',
      'Downtown Cairo',
      'Fifth Settlement',
      'Garden City',
      'Heliopolis',
      'Hyde Park',
      'Katameya',
      'Katameya Heights',
      'Madinaty',
      'Maadi',
      'Mivida',
      'Mokattam',
      'Mountain View iCity',
      'Nasr City',
      'New Administrative Capital',
      'New Cairo',
      'Palm Hills New Cairo',
      'Rehab',
      'Sarai',
      'Sheraton',
      'Shorouk City',
      'Taj City',
      'Zamalek',
    ],
  ),
  EgyptGovernorate(
    name: 'Giza',
    isPriority: true,
    areas: [
      '6th October',
      'Agouza',
      'Allegria',
      'Beverly Hills',
      'Courtyards',
      'Dokki',
      'Faisal',
      'Haram',
      'Mohandessin',
      'Mountain View Chillout',
      'Mountain View October',
      'Palm Hills October',
      'Sheikh Zayed',
      'Smart Village',
      'Sodic West',
      'West Somid',
      'ZED West',
    ],
  ),
  EgyptGovernorate(
    name: 'North Coast (Matrouh)',
    isPriority: true,
    areas: [
      'Almaza Bay',
      'Amwaj',
      'Azha North Coast',
      'Bianchi',
      'Caesar Bay',
      'Direction White',
      'Fouka Bay',
      'Gaia',
      'Hacienda Bay',
      'Hacienda White',
      'Jefaira',
      'June Sodic',
      'Koun',
      'La Vista Bay',
      'La Vista Cascada',
      'LVLS',
      'Marina 1',
      'Marina 2',
      'Marina 3',
      'Marina 4',
      'Marina 5',
      'Marina 6',
      'Marina 7',
      'Marina 8',
      'Marassi',
      'Mountain View Ras El Hikma',
      'Porto Marina',
      'Ras El Hikma',
      'Salt',
      'Seashell',
      'Sidi Abdelrahman',
      'Silver Sands',
      'Stella Heights',
      'Swan Lake North Coast',
      'Telal',
      'Waterway North Coast',
      'New Alamein',
      'El Alamein',
    ],
  ),

  // ---------------------------------------------------------------
  // ALL OTHER GOVERNORATES (alphabetical)
  // ---------------------------------------------------------------
  EgyptGovernorate(name: 'Alexandria', areas: [
    'Agami', 'Borg El Arab', 'Gleem', 'Mandara', 'Miami', 'Montaza',
    'New Borg El Arab', 'Roushdy', 'San Stefano', 'Sidi Gaber', 'Smouha',
    'Sporting', 'Stanley',
  ]),
  EgyptGovernorate(name: 'Aswan', areas: ['Aswan', 'New Aswan']),
  EgyptGovernorate(name: 'Assiut', areas: ['Assiut City']),
  EgyptGovernorate(name: 'Beheira', areas: [
    'Damanhour', 'Edku', 'Kafr El Dawwar', 'Rashid',
  ]),
  EgyptGovernorate(name: 'Beni Suef', areas: ['Beni Suef', 'New Beni Suef']),
  EgyptGovernorate(name: 'Dakahlia', areas: [
    'Dekernes', 'Mansoura', 'Mit Ghamr', 'New Mansoura', 'Talkha',
  ]),
  EgyptGovernorate(name: 'Damietta', areas: [
    'Damietta', 'New Damietta', 'Ras El Bar',
  ]),
  EgyptGovernorate(name: 'Fayoum', areas: ['Fayoum City']),
  EgyptGovernorate(name: 'Gharbia', areas: [
    'El Mahalla El Kubra', 'Kafr El Zayat', 'Tanta',
  ]),
  EgyptGovernorate(name: 'Ismailia', areas: [
    'Abu Sultan', 'El Qantara East', 'El Qantara West', 'Fayed', 'Ismailia',
  ]),
  EgyptGovernorate(name: 'Kafr El Sheikh', areas: [
    'Baltim', 'Desouk', 'Kafr El Sheikh',
  ]),
  EgyptGovernorate(name: 'Luxor', areas: ['Luxor East Bank', 'Luxor West Bank']),
  EgyptGovernorate(
    name: 'Matrouh (excluding North Coast resorts already listed)',
    areas: ['Marsa Matrouh', 'Siwa'],
  ),
  EgyptGovernorate(name: 'Menoufia', areas: [
    'Menouf', 'Sadat City', 'Shebin El Kom',
  ]),
  EgyptGovernorate(name: 'Minya', areas: ['Minya', 'New Minya']),
  EgyptGovernorate(name: 'New Valley', areas: ['Dakhla', 'Farafra', 'Kharga']),
  EgyptGovernorate(name: 'North Sinai', areas: [
    'Arish', 'Rafah', 'Sheikh Zuweid',
  ]),
  EgyptGovernorate(name: 'Port Said', areas: ['Port Fouad', 'Port Said']),
  EgyptGovernorate(name: 'Qalyubia', areas: [
    'Banha', 'Obour City', 'Qalyub', 'Shubra El Kheima',
  ]),
  EgyptGovernorate(name: 'Qena', areas: ['Nag Hammadi', 'Qena']),
  EgyptGovernorate(name: 'Red Sea', areas: [
    'El Gouna', 'El Quseir', 'Hurghada', 'Makadi Bay', 'Marsa Alam',
    'Port Ghalib', 'Safaga', 'Sahl Hasheesh', 'Soma Bay',
  ]),
  EgyptGovernorate(name: 'Sharqia', areas: [
    '10th of Ramadan', 'Abu Hammad', 'Belbeis', 'Minya El Qamh', 'Zagazig',
  ]),
  EgyptGovernorate(name: 'Sohag', areas: ['Akhmim', 'Sohag']),
  EgyptGovernorate(name: 'South Sinai', areas: [
    'Dahab', 'El Tor', 'Hadaba', 'Naama Bay', 'Nabq', 'Nuweiba',
    'Ras Sedr', 'Sharm El Sheikh', 'Sharks Bay', 'Soho Square', 'Taba',
  ]),
  EgyptGovernorate(name: 'Suez', areas: [
    'Ain Sokhna', 'Azha Sokhna', 'Galala', 'IL Monte Galala',
    'La Vista Sokhna', 'Porto Sokhna', 'Suez', 'Telal Ain Sokhna',
  ]),
];

List<String> get kAllGovernorateNames => kEgyptGovernorates.map((g) => g.name).toList();

List<String> areasFor(String? governorate) {
  if (governorate == null) return const [];
  for (final g in kEgyptGovernorates) {
    if (g.name == governorate) return g.areas;
  }
  return const [];
}

bool isKnownGovernorate(String? name) => name != null && kAllGovernorateNames.contains(name);

bool isKnownArea(String? governorate, String? area) =>
    area != null && areasFor(governorate).contains(area);
