import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../../state/app_state.dart';
import '../../models/charger_profile.dart';
import '../../models/availability_slot.dart';
import '../../models/enums.dart';
import '../../services/auth_service.dart';
import '../../services/pricing_service.dart';
import '../../data/egypt_locations.dart';
import '../../theme/ps_ev_theme.dart';
import '../../theme/ps_ev_app_bar.dart';
import '../shared/location_picker_field.dart';
import 'pick_location_on_map_screen.dart';

({double lat, double lng})? tryParseLatLngFromMapLink(String? link) {
  if (link == null || link.trim().isEmpty) return null;
  final match = RegExp(r'(-?\d{1,3}\.\d+)\s*,\s*(-?\d{1,3}\.\d+)').firstMatch(link);
  if (match == null) return null;
  final lat = double.tryParse(match.group(1)!);
  final lng = double.tryParse(match.group(2)!);
  if (lat == null || lng == null) return null;
  if (lat < -90 || lat > 90 || lng < -180 || lng > 180) return null;
  return (lat: lat, lng: lng);
}

/// Item #4 of the 30/8 update: hosts weren't reminded to set an
/// availability window, and a charger with zero windows is effectively
/// invisible/unbookable to drivers. Rather than silently leaving new
/// chargers unbookable, a brand-new charger is auto-seeded with this
/// default recurring window (10 AM - 5 PM, every day, for the next 90
/// days) if the host doesn't add their own before saving - see
/// _submit() below. The Add Charger form also shows a reminder banner so
/// hosts know they can customize (or fully replace) this in Manage
/// Charger -> Free Charging Windows at any time.
const int kDefaultAvailabilityStartHour = 10;
const int kDefaultAvailabilityEndHour = 17;
const int kDefaultAvailabilityDays = 90;

class ChargerFormScreen extends StatefulWidget {
  final ChargerProfile? existing;
  const ChargerFormScreen({super.key, this.existing});
  @override
  State<ChargerFormScreen> createState() => _ChargerFormScreenState();
}

class _ChargerFormScreenState extends State<ChargerFormScreen> {
  late TextEditingController _nameCtrl;
  late TextEditingController _mapLinkCtrl;
  late TextEditingController _priceCtrl;
  // City/Area now use the shared curated Egypt location list (see
  // data/egypt_locations.dart), the exact same source
  // DriverHomeScreen's filter and the Home Installation & Equipment
  // request form use. This guarantees a host's charger and a driver's
  // filter always use identical spelling.
  String? _city;
  String? _area;
  late double _power;
  late double _ampere;
  late PricingModel _pricingModel;
  late bool _residentsOnly;
  late String _community;
  late ChargingStandard _chargingStandard;
  late ConnectorType _connector;
  Uint8List? _photoBytes;
  String? _priceError;
  bool get isEditing => widget.existing != null;
  late final String _pendingChargerId;

  // ---------------------------------------------------------------------
  // Item #3: exact pin picked on an interactive map (see
  // PickLocationOnMapScreen), replacing "paste a Maps link" as the
  // primary/most-accurate way to place a charger. Takes top priority in
  // _resolveCoordinates() over both the Maps-link text parser and the
  // governorate-center fallback.
  // ---------------------------------------------------------------------
  double? _pickedLat;
  double? _pickedLng;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _pendingChargerId = e?.chargerId ?? 'charger_${DateTime.now().millisecondsSinceEpoch}';
    _nameCtrl = TextEditingController(text: e?.label ?? 'My Home Charger');
    _mapLinkCtrl = TextEditingController(text: e?.mapLink ?? '');
    _priceCtrl = TextEditingController(text: e?.price.toString() ?? '');
    // Only carry over the existing charger's city/area if they're still
    // present in the curated list - an older charger saved under the
    // previous (different) city/area names will start blank here and
    // the host will need to re-pick from the new list once, which also
    // has the side effect of automatically fixing that mismatch.
    _city = (e != null && isKnownGovernorate(e.city)) ? e.city : null;
    _area = (e != null && isKnownArea(_city, e.area)) ? e.area : null;
    _power = e?.powerKw ?? kPowerOptions[3];
    _ampere = e?.ampere ?? kAmpereOptions[1];
    _pricingModel = e?.pricingModel ?? PricingModel.perMinute;
    _residentsOnly = e?.residentsOnly ?? false;
    _community = e?.restrictedCommunity ?? kCommunityOptions.first;
    _photoBytes = e?.photoBytes;
    _chargingStandard = e?.chargingStandard ?? ChargingStandard.europeanCcs2;
    final validConnectors = _chargingStandard.compatibleConnectors;
    _connector = (e != null && validConnectors.contains(e.connector)) ? e.connector : validConnectors.first;
    // Pre-fill the picked pin from an existing charger's stored
    // coordinates so "Change Pin Location" opens centered on where the
    // charger already is, instead of resetting to the governorate center.
    if (e != null) {
      _pickedLat = e.latitude;
      _pickedLng = e.longitude;
    }
  }

  Future<void> _pickPhoto() async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt_outlined),
              title: const Text('Take a Photo'),
              onTap: () => Navigator.pop(sheetContext, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('Choose from Gallery'),
              onTap: () => Navigator.pop(sheetContext, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;
    try {
      final file = await ImagePicker().pickImage(source: source, imageQuality: 80);
      if (file == null) return;
      final bytes = await file.readAsBytes();
      if (mounted) setState(() => _photoBytes = bytes);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not load that image: $e'), backgroundColor: PsEvColors.red),
        );
      }
    }
  }

  void _validatePriceLive(String value) {
    final price = double.tryParse(value);
    final limits = PricingService.limitsFor(_pricingModel);
    setState(() {
      if (price == null) {
        _priceError = null;
      } else if (price < limits.min || price > limits.max) {
        _priceError = 'Must be ${limits.min}–${limits.max} ${limits.unitLabel}';
      } else {
        _priceError = null;
      }
    });
  }

  /// Opens the interactive map picker (see PickLocationOnMapScreen),
  /// centered on the currently picked pin if there is one, otherwise on
  /// the selected governorate's center, otherwise Cairo.
  Future<void> _openMapPicker() async {
    final start = (_pickedLat != null && _pickedLng != null)
        ? (lat: _pickedLat!, lng: _pickedLng!)
        : (kGovernorateCoordinates[_city] ?? kGovernorateCoordinates['Cairo']!);
    final result = await Navigator.push<({double lat, double lng})>(
      context,
      MaterialPageRoute(
        builder: (_) => PickLocationOnMapScreen(initialLat: start.lat, initialLng: start.lng),
      ),
    );
    if (result != null && mounted) {
      setState(() {
        _pickedLat = result.lat;
        _pickedLng = result.lng;
      });
    }
  }

  /// Resolves the final stored coordinates for this charger. Priority
  /// order (highest first):
  ///   1. A pin the host picked on the interactive map (_pickedLat/Lng) -
  ///      the most accurate option, see PickLocationOnMapScreen.
  ///   2. Coordinates parsed out of a pasted Maps link, if it happens to
  ///      contain them (kept for backward compatibility/power users -
  ///      many shortened links do NOT contain coordinates, which is why
  ///      the map picker above is now the primary method).
  ///   3. The selected governorate's approximate center, with a small
  ///      jitter so multiple chargers in the same city don't stack.
  ///   4. The existing charger's last known location (when editing).
  ///   5. Cairo center, as an absolute last resort.
  ({double lat, double lng}) _resolveCoordinates() {
    if (_pickedLat != null && _pickedLng != null) {
      return (lat: _pickedLat!, lng: _pickedLng!);
    }
    final fromLink = tryParseLatLngFromMapLink(_mapLinkCtrl.text);
    if (fromLink != null) return fromLink;
    final govCenter = kGovernorateCoordinates[_city];
    if (govCenter != null) {
      final jitter = jitterOffsetFor(_pendingChargerId);
      return (lat: govCenter.lat + jitter.lat, lng: govCenter.lng + jitter.lng);
    }
    if (widget.existing != null) {
      return (lat: widget.existing!.latitude, lng: widget.existing!.longitude);
    }
    // Fallback if somehow no governorate matched yet - Cairo center.
    return kGovernorateCoordinates['Cairo']!;
  }

  /// Item #4: seeds a default recurring 10 AM-5 PM daily window for the
  /// next kDefaultAvailabilityDays days on a BRAND NEW charger, so it's
  /// never left completely unbookable just because the host didn't
  /// visit Manage Charger -> Free Charging Windows yet. Hosts can freely
  /// edit or delete these default slots (or add their own custom ones)
  /// at any time from Manage Charger - this only ever runs once, at
  /// creation time.
  List<AvailabilitySlot> _buildDefaultAvailability(String chargerId) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    return List.generate(kDefaultAvailabilityDays, (i) {
      final day = today.add(Duration(days: i));
      return AvailabilitySlot(
        id: 'default_${chargerId}_$i',
        chargerId: chargerId,
        start: DateTime(day.year, day.month, day.day, kDefaultAvailabilityStartHour),
        end: DateTime(day.year, day.month, day.day, kDefaultAvailabilityEndHour),
        recurrenceLabel: 'Default $kDefaultAvailabilityStartHour AM–${kDefaultAvailabilityEndHour - 12} PM',
      );
    });
  }

  void _submit() {
    final app = context.read<AppState>();
    final price = double.tryParse(_priceCtrl.text);
    if (_nameCtrl.text.trim().isEmpty || price == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in all charger details.'), backgroundColor: PsEvColors.red),
      );
      return;
    }
    if (_city == null || _area == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select the City and Area for this charger.'), backgroundColor: PsEvColors.red),
      );
      return;
    }
    if (!PricingService.isPriceValid(_pricingModel, price)) {
      final l = PricingService.limitsFor(_pricingModel);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Price must be between ${l.min} and ${l.max} ${l.unitLabel} — please enter a realistic value.'), backgroundColor: PsEvColors.red),
      );
      return;
    }
    if (_residentsOnly && _community.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select which compound/community this charger is restricted to.'), backgroundColor: PsEvColors.red),
      );
      return;
    }
    final coords = _resolveCoordinates();
    if (isEditing) {
      final ch = widget.existing!;
      ch.label = _nameCtrl.text.trim();
      ch.city = _city!;
      ch.area = _area!;
      ch.mapLink = _mapLinkCtrl.text.trim().isEmpty ? null : _mapLinkCtrl.text.trim();
      ch.connector = _connector;
      ch.powerKw = _power;
      ch.ampere = _ampere;
      ch.pricingModel = _pricingModel;
      ch.price = price;
      ch.photoBytes = _photoBytes ?? ch.photoBytes;
      ch.residentsOnly = _residentsOnly;
      ch.restrictedCommunity = _residentsOnly ? _community : null;
      ch.chargingStandard = _chargingStandard;
      ch.latitude = coords.lat;
      ch.longitude = coords.lng;
      app.updateCharger(ch);
      Navigator.pop(context, true);
    } else {
      final charger = ChargerProfile(
        hostId: app.currentUserId ?? '',
        chargerId: _pendingChargerId,
        label: _nameCtrl.text.trim(),
        powerKw: _power,
        ampere: _ampere,
        connector: _connector,
        city: _city!,
        area: _area!,
        chargingStandard: _chargingStandard,
        pricingModel: _pricingModel,
        price: price,
        latitude: coords.lat,
        longitude: coords.lng,
        photoBytes: _photoBytes,
        mapLink: _mapLinkCtrl.text.trim().isEmpty ? null : _mapLinkCtrl.text.trim(),
        residentsOnly: _residentsOnly,
        restrictedCommunity: _residentsOnly ? _community : null,
      );
      // Item #4: default availability so the charger isn't invisible to
      // drivers until the host visits Manage Charger.
      charger.freeSlots.addAll(_buildDefaultAvailability(charger.chargerId));
      app.addCharger(charger);
      Navigator.pop(context, true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.read<AuthService>();
    final app = context.read<AppState>();
    final limits = PricingService.limitsFor(_pricingModel);
    final hint = PricingService.hintText(_pricingModel, _power, double.tryParse(_priceCtrl.text) ?? 0);
    final connectorsForStandard = _chargingStandard.compatibleConnectors;
    final hasPickedPin = _pickedLat != null && _pickedLng != null;
    return Scaffold(
      appBar: PsEvAppBar(title: isEditing ? 'Edit Charger' : 'Add Charger'),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Station photo', style: TextStyle(fontSize: 12, color: PsEvColors.mutedText)),
                  const SizedBox(height: 6),
                  if (_photoBytes != null)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.memory(_photoBytes!, height: 130, width: double.infinity, fit: BoxFit.cover),
                    ),
                  const SizedBox(height: 6),
                  InkWell(
                    onTap: _pickPhoto,
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      width: double.infinity,
                      decoration: BoxDecoration(
                        border: Border.all(color: PsEvColors.slate200, width: 2),
                        borderRadius: BorderRadius.circular(14),
                        color: PsEvColors.slate100.withOpacity(0.5),
                      ),
                      child: Text(
                        _photoBytes == null ? '📷 Add station photo (Camera or Gallery)' : '📷 Change photo (Camera or Gallery)',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text('Charger name', style: TextStyle(fontSize: 12, color: PsEvColors.mutedText)),
                  const SizedBox(height: 4),
                  TextField(controller: _nameCtrl),
                  const SizedBox(height: 12),
                  // City/Area picker - shared with the driver filter and
                  // service request form (see egypt_locations.dart /
                  // LocationPickerField), so this charger will always be
                  // discoverable by drivers filtering the same City/Area.
                  const Text('City & Area', style: TextStyle(fontSize: 12, color: PsEvColors.mutedText)),
                  const SizedBox(height: 4),
                  LocationPickerField(
                    governorate: _city,
                    area: _area,
                    showAllOption: false,
                    userId: app.currentUserId ?? '',
                    userName: auth.displayName,
                    onGovernorateChanged: (v) => setState(() {
                      _city = v;
                      _area = null;
                    }),
                    onAreaChanged: (v) => setState(() => _area = v),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(top: 4, bottom: 8),
                    child: Text(
                      'City and Area are used for filtering/search, and must match the same list drivers '
                      'use. For a precise pin at your exact address, use "Pick Exact Location on Map" below - '
                      'it\'s more reliable than a pasted Maps link, which often doesn\'t contain exact coordinates.',
                      style: TextStyle(fontSize: 11, color: PsEvColors.mutedText),
                    ),
                  ),
                  // -----------------------------------------------------
                  // Item #3: interactive map picker - the recommended,
                  // most accurate way to place this charger's pin.
                  // -----------------------------------------------------
                  PsEvSoftButton(
                    icon: Icons.pin_drop_outlined,
                    label: hasPickedPin ? 'Change Pin Location' : 'Pick Exact Location on Map',
                    onTap: _openMapPicker,
                  ),
                  if (hasPickedPin)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Row(
                        children: [
                          const Icon(Icons.check_circle, size: 14, color: PsEvColors.emerald),
                          const SizedBox(width: 4),
                          Text(
                            'Custom pin set (${_pickedLat!.toStringAsFixed(5)}, ${_pickedLng!.toStringAsFixed(5)})',
                            style: const TextStyle(fontSize: 11, color: PsEvColors.emerald, fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ),
                  const SizedBox(height: 12),
                  const Text('Maps link (optional)', style: TextStyle(fontSize: 12, color: PsEvColors.mutedText)),
                  const SizedBox(height: 4),
                  TextField(controller: _mapLinkCtrl, decoration: const InputDecoration(hintText: 'https://maps.google.com/?q=30.0131,31.4326')),
                  const Padding(
                    padding: EdgeInsets.only(top: 4, bottom: 4),
                    child: Text(
                      'Only used if you have NOT picked a pin above. Note: many shortened Google Maps links '
                      "(maps.app.goo.gl/...) don't contain usable coordinates - the map picker above is more reliable.",
                      style: TextStyle(fontSize: 11, color: PsEvColors.mutedText),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text('Charging standard', style: TextStyle(fontSize: 12, color: PsEvColors.mutedText)),
                  const SizedBox(height: 4),
                  DropdownButtonFormField<ChargingStandard>(
                    value: _chargingStandard,
                    items: ChargingStandard.values.map((s) => DropdownMenuItem(value: s, child: Text(s.label))).toList(),
                    onChanged: (v) => setState(() {
                      _chargingStandard = v!;
                      _connector = _chargingStandard.compatibleConnectors.first;
                    }),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(top: 6, bottom: 8),
                    child: Text(
                      'Select the standard this physical station is actually wired for. Type 2 and CCS2 only '
                      'ever belong to the European/International standard; Chinese GB/T stations use entirely '
                      'different, incompatible AC/DC connectors.',
                      style: TextStyle(fontSize: 11, color: PsEvColors.mutedText),
                    ),
                  ),
                  const Text('Connector type', style: TextStyle(fontSize: 12, color: PsEvColors.mutedText)),
                  const SizedBox(height: 4),
                  DropdownButtonFormField<ConnectorType>(
                    value: _connector,
                    items: connectorsForStandard.map((c) => DropdownMenuItem(value: c, child: Text(c.label))).toList(),
                    onChanged: (v) => setState(() => _connector = v!),
                  ),
                  const SizedBox(height: 12),
                  const Text('Power (kW)', style: TextStyle(fontSize: 12, color: PsEvColors.mutedText)),
                  const SizedBox(height: 4),
                  DropdownButtonFormField<double>(
                    value: _power,
                    items: kPowerOptions.map((p) => DropdownMenuItem(value: p, child: Text('$p kW'))).toList(),
                    onChanged: (v) => setState(() => _power = v!),
                  ),
                  const SizedBox(height: 12),
                  const Text('Ampere (A)', style: TextStyle(fontSize: 12, color: PsEvColors.mutedText)),
                  const SizedBox(height: 4),
                  DropdownButtonFormField<double>(
                    value: _ampere,
                    items: kAmpereOptions.map((a) => DropdownMenuItem(value: a, child: Text('${a.toStringAsFixed(0)} A'))).toList(),
                    onChanged: (v) => setState(() => _ampere = v!),
                  ),
                  const SizedBox(height: 12),
                  const Text('Pricing model', style: TextStyle(fontSize: 12, color: PsEvColors.mutedText)),
                  const SizedBox(height: 4),
                  DropdownButtonFormField<PricingModel>(
                    value: _pricingModel,
                    items: const [
                      DropdownMenuItem(value: PricingModel.perMinute, child: Text('Per Minute (time-based)')),
                      DropdownMenuItem(value: PricingModel.perKwh, child: Text('Per kWh (energy-based)')),
                    ],
                    onChanged: (v) => setState(() {
                      _pricingModel = v!;
                      _validatePriceLive(_priceCtrl.text);
                    }),
                  ),
                  const SizedBox(height: 12),
                  Text('Price (${limits.unitLabel})', style: const TextStyle(fontSize: 12, color: PsEvColors.mutedText)),
                  const SizedBox(height: 4),
                  TextField(
                    controller: _priceCtrl,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    onChanged: _validatePriceLive,
                    decoration: InputDecoration(errorText: _priceError),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 4, bottom: 10),
                    child: Text(hint, style: const TextStyle(fontSize: 11, color: PsEvColors.emerald)),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    activeColor: PsEvColors.emerald,
                    title: const Text('Restrict to my compound/community residents only', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                    subtitle: const Text(
                      'Only drivers who selected the same community in their Car Profile will be able to see and book this charger.',
                      style: TextStyle(fontSize: 11),
                    ),
                    value: _residentsOnly,
                    onChanged: (v) => setState(() => _residentsOnly = v),
                  ),
                  if (_residentsOnly)
                    Padding(
                      padding: const EdgeInsets.only(top: 6, bottom: 6),
                      child: DropdownButtonFormField<String>(
                        value: _community,
                        decoration: const InputDecoration(labelText: 'Which compound/community?'),
                        items: kCommunityOptions.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                        onChanged: (v) => setState(() => _community = v!),
                      ),
                    ),
                  // ---------------------------------------------------
                  // Item #4: availability reminder, only shown while
                  // creating a brand-new charger (an existing charger's
                  // real windows are already managed in Manage Charger).
                  // ---------------------------------------------------
                  if (!isEditing)
                    Container(
                      margin: const EdgeInsets.only(top: 12),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(color: PsEvColors.amberChip, borderRadius: BorderRadius.circular(12)),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.info_outline, size: 16, color: PsEvColors.amberChipText),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              "Don't forget to set this charger's real availability afterwards, in "
                              "Manage Charger → Free Charging Windows. If you skip it, we'll default it to "
                              "$kDefaultAvailabilityStartHour AM–${kDefaultAvailabilityEndHour - 12} PM every day "
                              "for the next $kDefaultAvailabilityDays days so drivers can still find and book it.",
                              style: const TextStyle(fontSize: 11, color: PsEvColors.amberChipText),
                            ),
                          ),
                        ],
                      ),
                    ),
                  const SizedBox(height: 12),
                  PsEvFilledButton(
                    label: isEditing ? 'Save Changes' : 'Save Charger',
                    onTap: _submit,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
