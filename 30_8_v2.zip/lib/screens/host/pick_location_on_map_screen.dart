import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../../theme/ps_ev_theme.dart';

/// Item #3 of the 30/8 update: "the maps link I tried is not accurate,
/// while having the user enter coordinates is difficult."
///
/// Root cause: a pasted Google Maps link only contains parseable
/// "lat,lng" text for certain link formats - a SHORTENED link (e.g.
/// maps.app.goo.gl/xxxx, or a plain place-name search link) has no
/// coordinates in it at all, so ChargerFormScreen's regex-based parser
/// (tryParseLatLngFromMapLink) silently falls back to the governorate's
/// center point instead - which is what looked "not accurate".
///
/// This screen replaces "paste a link" / "type coordinates by hand" with
/// a plain drag-and-tap map: the host pans/zooms to their charger's real
/// location and taps to drop a pin exactly there. Returns the picked
/// (lat, lng) as a record to the caller (ChargerFormScreen), which stores
/// it directly - no link parsing, no manual coordinate typing required.
class PickLocationOnMapScreen extends StatefulWidget {
  final double initialLat;
  final double initialLng;
  const PickLocationOnMapScreen({super.key, required this.initialLat, required this.initialLng});

  @override
  State<PickLocationOnMapScreen> createState() => _PickLocationOnMapScreenState();
}

class _PickLocationOnMapScreenState extends State<PickLocationOnMapScreen> {
  late LatLng _picked;

  @override
  void initState() {
    super.initState();
    _picked = LatLng(widget.initialLat, widget.initialLng);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pick Exact Charger Location'),
        backgroundColor: Colors.white,
        foregroundColor: PsEvColors.slate950,
        elevation: 0,
      ),
      body: Stack(
        children: [
          FlutterMap(
            options: MapOptions(
              initialCenter: _picked,
              initialZoom: 16,
              onTap: (tapPosition, point) => setState(() => _picked = point),
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.evpairapp.evpair',
                maxNativeZoom: 19,
              ),
              MarkerLayer(
                markers: [
                  Marker(
                    point: _picked,
                    width: 46,
                    height: 46,
                    child: const Icon(Icons.location_on, size: 46, color: PsEvColors.emerald),
                  ),
                ],
              ),
            ],
          ),
          Positioned(
            top: 12,
            left: 16,
            right: 16,
            child: Material(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              elevation: 4,
              shadowColor: Colors.black26,
              child: const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  'Pan and zoom the map, then tap exactly where your charger is. This is more accurate than pasting a Maps link.',
                  style: TextStyle(fontSize: 12, color: PsEvColors.mutedText),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 24,
            child: PsEvFilledButton(
              icon: Icons.check_circle_outline,
              label: 'Use This Location',
              onTap: () => Navigator.pop(context, (lat: _picked.latitude, lng: _picked.longitude)),
            ),
          ),
        ],
      ),
    );
  }
}
